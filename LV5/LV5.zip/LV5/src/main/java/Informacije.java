public interface Informacije {
    public String predstavi();
}

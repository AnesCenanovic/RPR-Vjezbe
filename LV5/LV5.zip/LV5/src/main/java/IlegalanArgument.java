public class IlegalanArgument extends Exception{

    public IlegalanArgument(String poruka){
        super(poruka);
    }
}

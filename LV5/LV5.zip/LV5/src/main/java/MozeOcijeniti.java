
public interface MozeOcijeniti {

    public Ocjena ocijeni(int x);
}

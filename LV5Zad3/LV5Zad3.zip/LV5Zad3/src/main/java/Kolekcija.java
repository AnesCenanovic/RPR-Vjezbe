public interface Kolekcija {
    String getNajduzeIme();
}

package com.example.lv4;

import static org.junit.jupiter.api.Assertions.*;

class LaptopDaoJSONFileTest {

    public void testDodajLaptopUListu() {
    }

    public void testGetLaptop() {
    }

    public void testNapuniListu() {
    }

    public void testVratiPodatkeIzDatoteke() {
    }

    public void testDodajLaptopUFile() {
    }
}
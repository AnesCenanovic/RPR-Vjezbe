package com.example.lv4;

import static org.junit.jupiter.api.Assertions.*;

class LaptopDaoXMLFileTest {

    public void testDodajLaptopUListu() {
    }

    public void testGetLaptop() {
    }

    public void testNapuniListu() {
    }

    public void testVratiPodatkeIzDatoteke() {
    }

    public void testDodajLaptopUFile() {
    }
}
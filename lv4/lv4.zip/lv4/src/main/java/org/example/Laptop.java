package org.example;


public abstract class Laptop implements LaptopDao{
    private String brend;
    private String model;
    private double cijena;
    private int ram;
    private int hdd;
    private int ssd;
    private String procesor;
    private String grafickaKartica;
    private String velicinaEkrana;

    public Laptop (){

    }

    public Laptop (String brend, String model, double cijena, int ram, int hdd, int ssd, String procesor, String grafickaKartica, String velicinaEkrana){
        this.brend=brend;
        this.cijena=cijena;
        this.grafickaKartica=grafickaKartica;
        this.model=model;
        this.hdd=hdd;
        this.ssd=ssd;
        this.ram=ram;
        this.procesor=procesor;
        this.velicinaEkrana=velicinaEkrana;
    }

    public String getBrend(){
        return this.brend;
    }
    public String getModel(){
        return this.model;
    }
    public double getCijena(){
        return this.cijena;
    }
    public int getRam(){
        return this.ram;
    }
    public int getHdd(){
        return this.hdd;
    }
    public int getSsd(){
        return this.ssd;
    }
    public String getProcesor(){
        return this.procesor;
    }
    public String getGrafickaKartica(){
        return this.grafickaKartica;
    }
    public String getVelicinaEkrana(){
        return this.velicinaEkrana;
    }


    public void getBrend(){
        return this.brend;
    }
    public void getModel(){
        return this.model;
    }
    public void getCijena(){
        return this.cijena;
    }
    public void getRam(){
        return this.ram;
    }
    public void getHdd(){
        return this.hdd;
    }
    public void getSsd(){
        return this.ssd;
    }
    public void getProcesor(){
        return this.procesor;
    }
    public void getGrafickaKartica(){
        return this.grafickaKartica;
    }
    public String getVelicinaEkrana(){
        return this.velicinaEkrana;
    }




}
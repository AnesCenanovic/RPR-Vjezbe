package org.example;

public class Program {
}

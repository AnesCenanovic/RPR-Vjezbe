package com.example.lv4;

public class Izuzetak extends Exception{
    Izuzetak(String poruka){
        super(poruka);
    }
}

package com.example.lv4;
import java.io.File;
import java.util.*;

public class LaptopDaoXMLFile implements LaptopDao{
    private File file;
    private ArrayList<Laptop> laptopi;


}
